
<div class="avatar av-l chatify-d-flex"></div>
<p class="info-name"><?php echo e(config('chatify.name')); ?></p>
<div class="messenger-infoView-btns">
    <a href="#" class="danger delete-conversation">Eliminar Conversación</a>
</div>

<div class="messenger-infoView-shared">
    <p class="messenger-title"><span>Fotos compartidas</span></p>
    <div class="shared-photos-list"></div>
</div>
<?php /**PATH C:\Users\52331\Desktop\e3dUSA\resources\views/vendor/Chatify/layouts/info.blade.php ENDPATH**/ ?>