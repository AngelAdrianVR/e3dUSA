<script setup>
import { Link } from '@inertiajs/vue3';
</script>

<template>
    <Link :href="'/'">
    <figure>
        <img class="w-[40%] mx-auto" src="@/../../public/images/logo.png" alt="Logo">
    </figure>
    </Link>
</template>
