<template>
    <figure>
        <img src="@/../../public/images/logo.png" alt="Logo">
    </figure>
</template>
